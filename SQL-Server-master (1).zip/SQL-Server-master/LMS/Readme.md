## Tài liệu trên hệ thống học kết hợp Learning management system
https://lms.dhcnhn.vn/


### Lý thuyết - Bài 1: Tổng quan về Hệ quản trị CSDL và xây dựng CSDL trên hệ quản trị CSDL SQL Server
### Thực hành/Thí nghiệm - Bài 2: Xây dựng CSDL trên hệ quản trị SQL Server
### Lý thuyết - Bài 3: Truy vấn dữ liệu trên Hệ quản trị CSDL SQL Server
### Thực hành/Thí nghiệm - Bài 4: Truy vấn dữ liệu trên hệ quản trị CSDL SQL Server
### Lý thuyết - Bài 5: Thao tác dữ liệu, tạo khung nhìn và lập trình hàm trong SQL Server
### Thực hành/Thí nghiệm - Bài 6: Thao tác dữ liệu, tạo khung nhìn trong SQL Server
### Thực hành/Thí nghiệm - Bài 7: Lập trình hàm trong SQL Server
### Lý thuyết - Bài 8: Lập trình thủ tục trong SQL Server
### Thực hành/Thí nghiệm - Bài 9: Lập trình thủ tục trong SQL Server
### Lý thuyết - Bài 10: Lập trình Trigger trong SQL Server
### Thực hành/Thí nghiệm - Bài 11: Lập trình Trigger trong SQL Server
### Lý thuyết - Bài 12: Bảo mật và Sao lưu, phục hồi dữ liệu trong SQL Server
### Thực hành/Thí nghiệm - Bài 13: Bảo mật và Sao lưu, phục hồi dữ liệu trong SQL Server