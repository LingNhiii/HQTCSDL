## Thư viện gồm 16 đề thi có đáp án

- Đây là các bài ôn tập trước khi thi kết thúc học phần
- Làm hết 16 đề này là auto 10 nhé!
- Tất cả các đề thi (xem trong thư mục DeThi) đều lấy từ 16 đề này ra chỉ đảo thui.
- Các đề có CSDL giống nhau đều được mình gộp vào 1 thư mục
- Đáp án có 2 loại là của thằng chủ và 1 đáp án lượm được (file nén trong Anh-De)
- Thế thui chăm làm vào

[Nam.Name.Vn](https://nam.name.vn/)