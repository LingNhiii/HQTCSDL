Câu hỏi trong đề y như vầy, t chụp nhầm nên lấy tạm cái ảnh đề này.
Nói chung đề nó same same nhau, có ý có thể mọi người đã làm ở đề khác rồi!