# SQL-Server
Bài tập + Giải đề thi SQL Server - Hệ quản trị Cơ sở dữ liệu (HQTCSDL) - HAUI
* Tài Liệu chỉ dùng để tham khảo
* Bài tập làm theo tư duy chủ quan, không phải chuẩn chỉnh 100%

Video giải một số đề mà mình lượm được: https://www.youtube.com/watch?v=-CMcHdVahCk